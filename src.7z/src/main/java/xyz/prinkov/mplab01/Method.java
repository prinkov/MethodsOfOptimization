package xyz.prinkov.mplab01;

import org.mariuszgromada.math.mxparser.Function;

abstract public class Method {
    abstract public double[] min(Function f);
}
